var_int = 10
var_float = 8.4
var_str = 'No'

var_int *= 3.5
var_big = var_int

var_float -= 1

var_int / var_float
var_big / var_float

var_str += var_str + 'Yes' * 3
print(f'''var_int = {var_int}
var_float = {var_float}
var_str = {var_str}
var_big = {var_big}''')
