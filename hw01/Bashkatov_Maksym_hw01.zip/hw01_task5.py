degree = 0

while degree < 21:
    print(2 ** degree)
    degree += 1
