numbers = [int(input('Введите число: ')) for i in range(8)]
print(f'''sum = {sum(numbers)}
max = {max(numbers)}
min = {min(numbers)}
''')
